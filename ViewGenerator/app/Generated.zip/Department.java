public class Department// extends <CLASS_NAME>
{
	private String Name;

	private final List<Manager> m_manager;

	public Department(List<Manager> manager) {
		//Super
		this.m_manager = manager;
	}

	public List<Manager>  getM_manager() {
		return this.m_manager;
	}

	public String getName() {
		return this.Name;
	}

	public void setName(String Name) {
		this.Name = Name; 
	}
	//Functions
}

