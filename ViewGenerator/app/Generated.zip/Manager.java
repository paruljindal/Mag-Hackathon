public class Manager// extends <CLASS_NAME>
{
	public String Name;
	private String Id;


	public Manager() {
		//Super
	}

	public String getId() {
		return this.Id;
	}

	public void setId(String Id) {
		this.Id = Id; 
	}
	//Functions
}

